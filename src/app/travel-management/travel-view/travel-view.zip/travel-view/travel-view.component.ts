import { FormGroup , FormBuilder , Validators} from "@angular/forms";
import { Component, OnInit, ViewChild, Inject, Optional } from "@angular/core";
import { ApiService } from "../../providers/api.service";
import { Router } from "@angular/router";
import { environment } from "../../../environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";


import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { DataTableDirective } from "angular-datatables";
import { TravelrequestDetailsComponent } from "../travelrequest-details/travelrequest-details.component";

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-travel-view',
  templateUrl: './travel-view.component.html',
  styleUrls: ['./travel-view.component.css']
})
export class TravelViewComponent implements OnInit {
  @ViewChild(DataTableDirective, { static: false })
  datatableElement: DataTableDirective;


  dtOptions: DataTables.Settings = {};
  dataAr: any[];
  DataAr: any[];
  SearchForm: FormGroup;
  TravelForm: FormGroup;
  Logs_Id : any;
  url_segment:string;
  ApprovalStatus: any;
  isSubmitted = false;
  Id: any;
  Remark: any;
  status: any;
  UserName:any;

  constructor(
    private api: ApiService,
    private router: Router,
    private http: HttpClient,
    public dialog: MatDialog,
    private fb : FormBuilder,
    @Optional() private dialogRef: MatDialogRef<TravelrequestDetailsComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,

  ) { 
    this.url_segment = router.url.split('/')[2];
    const name = this.api.GetUserData('Name');
    const code = this.api.GetUserData('Code');
    this.UserName =`${name}-${code}`;
    
   
    

    this.TravelForm = this.fb.group({
      Remark : ["",Validators.required]
    });
    
  }

  ngOnInit() {
    this.Get();
  }
  get FormC() {
    return this.TravelForm.controls;
  }

  onClose() {
    document.getElementById('logs').click();
    document.getElementById('exampleModal').click();
  }

  ClearSearch() {
    var fields = this.SearchForm.reset();
    this.dataAr = [];
    this.ResetDT();
  }

  Reload() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.draw();
    });
  }

  ResetDT() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.search("").column(0).search("").draw();
    });
  }

  SearchData(event: any) {
    this.dataAr = [];
    this.datatableElement.dtInstance.then((dtInstance: any) => {

        dtInstance.column(0).search(JSON.stringify(event)).draw();
    });
  }

  Get() {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization:  this.api.GetToken(),
      }),
    };

    const that = this;

    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      serverSide: true,
      processing: true,
      ajax: (dataTablesParameters: any, callback) => {
        that.http.post<DataTablesResponse>(environment.apiUrl + "/TravelRequest/view_request?User_Id=" +this.api.GetUserData("Id") +"&User_Type=" +
              this.api.GetUserType() + "&url_segment=" + this.url_segment,dataTablesParameters,httpOptions )
          .subscribe((resp) => {
            that.dataAr = resp.data;

            if (that.dataAr.length > 0) { }

            callback({
              recordsTotal: resp.recordsTotal,
              recordsFiltered: resp.recordsFiltered,
              data: [],
            });
          });
      },
    };
  }

  Get_logs(Id:any){
    const formdata = new FormData();
    this.Id = Id;
    formdata.append('LogsId' , Id);
    formdata.append('User_Name' , this.api.GetUserData('Name'));
    formdata.append('User_type' , this.api.GetUserData('Type'));
    formdata.append('User_code' , this.api.GetUserData('Code'));
    formdata.append('url_segment' , this.url_segment);

    this.api.HttpPostType('TravelRequest/view_logs' , formdata)
    .then(
      (result:any) => {
        if(result['status'] == true){
          this.DataAr = result.data;
         
        }else{
          this.DataAr = [];
        }
      },
      (err) => {
        this.api.Toast("Warning", "Network Error : " + err.name + "(" + err.statusText + ")"
        );
      });
  }

  GetStatus(ApprovalStatus:any){
    this.ApprovalStatus = ApprovalStatus;
  }

  travel_Form(){
    this.isSubmitted = true;

    const formdata = new FormData();
  this.Remark =   this.TravelForm.get('Remark').value;
   
    formdata.append('ApprovalStatus' , this.ApprovalStatus);
    formdata.append('url_segment' , this.url_segment);
    formdata.append('LogsId' , this.Id);
    formdata.append('UserName' , this.api.GetUserData('Name'));
    formdata.append('UserCode' , this.api.GetUserData('Code'));
    formdata.append('UserId' , this.api.GetUserData('Id'));
    formdata.append('Remark' , this.Remark);

    this.api.HttpPostType('TravelRequest/Save_Logs' , formdata)
    .then(
      (result:any) => {
        if(result['status'] == true){
          this.api.Toast('Success' , result['msg']);
          this.onClose();
          this.ResetDT();
         
        }else{
          this.api.Toast('Warning' , result['msg']);
        }
      },
      (err) => {
        this.api.Toast("Warning", "Network Error : " + err.name + "(" + err.statusText + ")"
        );
      });
  }

  Edit_request(ID:any){
    this.router.navigate(['/travel_request/request/' + ID]);
  }

  GetRequest_Details(row_Id): void {
	  
		const dialogRef = this.dialog.open(TravelrequestDetailsComponent, {
		  width: '50%',
		  data: {Id : row_Id},
		  disableClose : true,
		});

		dialogRef.afterClosed().subscribe(result => {
		 
		});
	  
  }



}
